package kr.kdata.security.service;

import kr.kdata.security.vo.Users;

public interface MemberService {
	boolean joinOk(Users users);
}
