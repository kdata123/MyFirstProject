package kr.kdata.jwt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootJwtEx01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
