package kr.kdata.filter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootFilterEx01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
