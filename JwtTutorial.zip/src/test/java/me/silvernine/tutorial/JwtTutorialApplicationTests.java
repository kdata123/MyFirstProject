package me.silvernine.tutorial;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JwtTutorialApplicationTests {

	@Test
	void contextLoads() {
	}

}
