package kr.kdata.listener;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootListenerEx01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
