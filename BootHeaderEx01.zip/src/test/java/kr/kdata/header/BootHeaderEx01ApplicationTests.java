package kr.kdata.header;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootHeaderEx01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
