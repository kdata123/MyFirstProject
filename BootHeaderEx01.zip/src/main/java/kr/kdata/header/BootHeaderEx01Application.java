package kr.kdata.header;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootHeaderEx01Application {

	public static void main(String[] args) {
		SpringApplication.run(BootHeaderEx01Application.class, args);
	}

}
