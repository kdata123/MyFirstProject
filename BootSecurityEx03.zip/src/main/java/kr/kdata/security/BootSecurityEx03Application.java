package kr.kdata.security;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootSecurityEx03Application {
	public static void main(String[] args) {
		SpringApplication.run(BootSecurityEx03Application.class, args);
	}
}
