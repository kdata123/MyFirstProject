package kr.kdata.security;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootSecurityEx01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
